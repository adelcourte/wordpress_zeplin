# Starter plugin for WordPress and Gutenberg, the new editor!

Open a terminal and enter below command :

`npm install`

Waiting for the installation of dependencies<br>And... You can start to develop!

`npm run dev`

Have fun 😀

Version 1.1 :

- Add standardjs, eslint and lint files

- Move examples blocks in folder
