export const PLUGIN_NAME = 'in-block'
